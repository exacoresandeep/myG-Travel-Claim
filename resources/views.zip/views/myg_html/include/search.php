<div class="search-box">
  <div class="input-group row">
    <div class="col-md-9">
      <input type="text" placeholder="" class="form-control">
      <label>(Search using Invoice numbers, Sales order numbers, shipping bill numbers, client name, ect.)</label>
    </div>
    <div class="col-md-3">
      <input type="submit" placeholder="" class="btn btn-primary" value="Search">
      <label class="search-label"><a href="advanced-search.php">Advanced Search</a></label>
    </div>
  </div>
</div>